<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                Copyright © 2018 ERP. All rights reserved.
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            </div>
        </div>
    </div>
</div>
</div>
<!-- jquery 3.3.1 -->
<script src="<?php echo e(url('assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
<!-- bootstap bundle js -->
<script src="<?php echo e(url('assets/vendor/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
<!-- slimscroll js -->
<script src="<?php echo e(url('assets/vendor/slimscroll/jquery.slimscroll.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(url('assets/libs/js/main-js.js')); ?>"></script>
<!-- chart chartist js -->

<!-- sparkline js -->

<!-- morris js -->


<!-- chart c3 js -->





<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready( function () {
        $('#categories').DataTable();
        $('#types').DataTable();
        $('#colors').DataTable();
        $('#users').DataTable();
        $('#products').DataTable();
        $('#clients').DataTable();
    } );
</script>
</body>

</html><?php /**PATH C:\xampp\htdocs\erp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>